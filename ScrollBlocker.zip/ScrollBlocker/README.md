# 🔒 ScrollBlocker

Bloque le scroll sur Instagram et TikTok sans root.

---

## 📲 Obtenir l'APK SANS installer Android Studio

### Méthode : GitHub Actions (entièrement en ligne, gratuit)

**Étape 1 — Créer un compte GitHub**
→ https://github.com/signup (gratuit)

**Étape 2 — Créer un nouveau dépôt**
- Cliquer sur **"New repository"**
- Nom : `ScrollBlocker`
- Cocher **"Public"**
- Cliquer **"Create repository"**

**Étape 3 — Uploader les fichiers**
- Cliquer **"uploading an existing file"**
- Glisser-déposer TOUS les fichiers du ZIP extrait
- Cliquer **"Commit changes"**

**Étape 4 — Lancer la compilation**
- Aller dans l'onglet **"Actions"**
- Cliquer sur **"Build ScrollBlocker APK"**
- Cliquer **"Run workflow"** → **"Run workflow"**
- Attendre ~3 minutes ⏳

**Étape 5 — Télécharger l'APK**
- Cliquer sur le job terminé ✅
- En bas de page, section **"Artifacts"**
- Télécharger **"ScrollBlocker-APK"**
- Extraire le ZIP → tu as ton `app-debug.apk` !

**Étape 6 — Installer sur le téléphone**
- Envoie l'APK sur ton téléphone (email, Drive, câble...)
- Sur Android : Paramètres → Sécurité → Activer "Sources inconnues"
- Ouvrir l'APK → Installer

---

## 🔒 Utilisation
1. Ouvrir ScrollBlocker
2. Accorder les 2 permissions
3. Activer le switch
4. Ouvrir Instagram ou TikTok → le scroll est bloqué !

---

## ➕ Ajouter d'autres apps
Dans `app/src/main/java/com/scrollblocker/app/OverlayService.kt` :

```kotlin
private val BLOCKED_APPS = setOf(
    "com.instagram.android",
    "com.zhiliaoapp.musically",
    "com.reddit.frontpage",      // ← Reddit
    "com.twitter.android",       // ← X/Twitter
)
```
