package com.scrollblocker.app

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.scrollblocker.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateUI()

        binding.switchBlock.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!hasOverlayPermission()) {
                    requestOverlayPermission()
                    binding.switchBlock.isChecked = false
                    return@setOnCheckedChangeListener
                }
                if (!hasUsageStatsPermission()) {
                    requestUsageStatsPermission()
                    binding.switchBlock.isChecked = false
                    return@setOnCheckedChangeListener
                }
                startBlockingService()
                saveState(true)
                binding.statusText.text = "🔒 Protection activée"
                binding.statusText.setTextColor(getColor(android.R.color.holo_green_dark))
            } else {
                stopBlockingService()
                saveState(false)
                binding.statusText.text = "🔓 Protection désactivée"
                binding.statusText.setTextColor(getColor(android.R.color.holo_red_dark))
            }
        }

        binding.btnPermOverlay.setOnClickListener { requestOverlayPermission() }
        binding.btnPermUsage.setOnClickListener { requestUsageStatsPermission() }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        val overlayOk = hasOverlayPermission()
        val usageOk = hasUsageStatsPermission()
        val isActive = getSavedState()

        binding.permOverlayStatus.text = if (overlayOk) "✅ Accordée" else "❌ Manquante"
        binding.permUsageStatus.text = if (usageOk) "✅ Accordée" else "❌ Manquante"
        binding.btnPermOverlay.isEnabled = !overlayOk
        binding.btnPermUsage.isEnabled = !usageOk

        binding.switchBlock.isChecked = isActive && overlayOk && usageOk

        if (isActive && overlayOk && usageOk) {
            binding.statusText.text = "🔒 Protection activée"
            binding.statusText.setTextColor(getColor(android.R.color.holo_green_dark))
        } else {
            binding.statusText.text = "🔓 Protection désactivée"
            binding.statusText.setTextColor(getColor(android.R.color.holo_red_dark))
        }
    }

    private fun hasOverlayPermission(): Boolean = Settings.canDrawOverlays(this)

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun requestOverlayPermission() {
        Toast.makeText(this, "Autorise ScrollBlocker à s'afficher par-dessus les autres apps", Toast.LENGTH_LONG).show()
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivity(intent)
    }

    private fun requestUsageStatsPermission() {
        Toast.makeText(this, "Autorise ScrollBlocker à voir quelle app est active", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun startBlockingService() {
        val intent = Intent(this, OverlayService::class.java)
        startForegroundService(intent)
    }

    private fun stopBlockingService() {
        stopService(Intent(this, OverlayService::class.java))
    }

    private fun saveState(active: Boolean) {
        getSharedPreferences("prefs", MODE_PRIVATE).edit().putBoolean("active", active).apply()
    }

    private fun getSavedState(): Boolean {
        return getSharedPreferences("prefs", MODE_PRIVATE).getBoolean("active", false)
    }
}
