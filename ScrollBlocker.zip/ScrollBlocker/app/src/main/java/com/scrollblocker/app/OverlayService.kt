package com.scrollblocker.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "scroll_blocker_channel"
        private const val NOTIF_ID = 1001
        private const val CHECK_INTERVAL_MS = 500L

        // Apps à bloquer
        private val BLOCKED_APPS = setOf(
            "com.instagram.android",
            "com.zhiliaoapp.musically",   // TikTok
            "com.ss.android.ugc.trill",   // TikTok variante
            "com.bytedance.tiktok"        // TikTok variante
        )
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isOverlayShowing = false

    private val checkRunnable = object : Runnable {
        override fun run() {
            val currentApp = getForegroundApp()
            val shouldBlock = BLOCKED_APPS.contains(currentApp)

            if (shouldBlock && !isOverlayShowing) {
                showOverlay()
            } else if (!shouldBlock && isOverlayShowing) {
                hideOverlay()
            }

            handler.postDelayed(this, CHECK_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        handler.post(checkRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(checkRunnable)
        hideOverlay()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ────────────────────────────────────────────────
    // Overlay qui capture les événements de scroll
    // ────────────────────────────────────────────────

    private fun showOverlay() {
        if (overlayView != null) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // FLAG_NOT_FOCUSABLE : ne capture pas le clavier
            // FLAG_LAYOUT_IN_SCREEN : couvre tout l'écran
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        val view = createBlockingView()
        overlayView = view

        try {
            windowManager.addView(view, params)
            isOverlayShowing = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideOverlay() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        overlayView = null
        isOverlayShowing = false
    }

    /**
     * Vue transparente qui bloque les gestes verticaux (scroll)
     * mais laisse passer les taps normaux (pour que l'app reste utilisable).
     */
    private fun createBlockingView(): View {
        val view = object : View(this) {
            private var startY = 0f
            private var startX = 0f
            private val SCROLL_THRESHOLD = 20f  // px avant qu'on considère un scroll

            override fun onTouchEvent(event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        startX = event.rawX
                        return false  // Ne pas consommer le DOWN (laisse les taps passer)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = Math.abs(event.rawY - startY)
                        val dx = Math.abs(event.rawX - startX)
                        // Si c'est un scroll vertical → on bloque
                        if (dy > SCROLL_THRESHOLD && dy > dx) {
                            return true  // Consomme l'event → bloque le scroll
                        }
                        return false
                    }
                    else -> return false
                }
            }
        }
        // Complètement transparent
        view.setBackgroundColor(Color.TRANSPARENT)
        return view
    }

    // ────────────────────────────────────────────────
    // Détection de l'app au premier plan
    // ────────────────────────────────────────────────

    private fun getForegroundApp(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val time = System.currentTimeMillis()
        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            time - 10_000,
            time
        )
        return stats?.maxByOrNull { it.lastTimeUsed }?.packageName
    }

    // ────────────────────────────────────────────────
    // Notification persistante (obligatoire pour un Foreground Service)
    // ────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "ScrollBlocker actif",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "ScrollBlocker surveille Instagram et TikTok"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🔒 ScrollBlocker actif")
            .setContentText("Scroll bloqué sur Instagram et TikTok")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
